document.addEventListener('DOMContentLoaded', () => {
    // Select the container for links
    const linksContainer = document.querySelector('.links');

    // Event listener for adding a new link
    document.querySelector('.add-link').addEventListener('click', () => {
        // Create a new link element
        const newLink = document.createElement('a');
        newLink.href = '#'; // Set the link's URL
        newLink.className = 'link'; // Apply the link styling
        newLink.textContent = 'New Link'; // Set the link text
        linksContainer.appendChild(newLink); // Add the new link to the container
    });

    // Event listener for removing the last link
    document.querySelector('.remove-link').addEventListener('click', () => {
        if (linksContainer.lastElementChild) {
            // Remove the last link in the container
            linksContainer.removeChild(linksContainer.lastElementChild);
        }
    });
});